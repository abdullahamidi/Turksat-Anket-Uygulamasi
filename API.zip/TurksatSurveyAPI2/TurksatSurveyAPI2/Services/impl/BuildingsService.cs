﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository;

namespace TurksatSurveyAPI2.Services
{
    public class BuildingsService : IBuildingsService
    {
        private IUnitOfWork _unitofwork;

        public BuildingsService(IUnitOfWork unitofwork)
        {
            _unitofwork = unitofwork;
        }

        public IQueryable<Buildings> getBuildingByID(int id) => _unitofwork.BuildingRepository.getAllwithStreetID(id);


    }
}
