﻿using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository;

namespace TurksatSurveyAPI2.Services
{
    public class CityService : ICityService
    {
        private IUnitOfWork _unitofwork;

        public CityService(IUnitOfWork unitofwork)
        {
            _unitofwork = unitofwork;
        }


        public IQueryable<Cities> getAllCities() => _unitofwork.CitiesRepository.getAllCities();

        
        
    }
}
