﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository;

namespace TurksatSurveyAPI2.Services.impl
{
    public class SAddressService : ISAddressService
    {
        IUnitOfWork unitOfWork;

        public SAddressService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
}

        public int getID()
        {
           return unitOfWork.SAddressRepository.getID();
        }

        public void insertAddress(SurveyAddresses surveyAddresses)
        {
            unitOfWork.SAddressRepository.addSAddress(surveyAddresses);
        }
    }
}
