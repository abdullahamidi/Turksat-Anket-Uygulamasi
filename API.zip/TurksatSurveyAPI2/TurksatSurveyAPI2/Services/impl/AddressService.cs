﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository;

namespace TurksatSurveyAPI2.Services
{
    public class AddressService : IAddressService
    {
        IUnitOfWork _unitOfWork;

        public AddressService(IUnitOfWork unitofwork)
        {
            _unitOfWork = unitofwork;
        }

        public IQueryable<Buildings> getBuildingswithStreetID(int id)
        {
            return null;
        }

        public IQueryable<Districts> getDistrictswithTownID(int id)
        {
            throw new NotImplementedException();
        }

        public IQueryable<Flats> getFlatswithBuildingID(int id)
        {
            throw new NotImplementedException();
        }

        public IQueryable<Neighborhoods> getNeighborhoodwithDistrictID(int id)
        {
            throw new NotImplementedException();
        }

        public IQueryable<Streets> getStreetswithNeighborhoodID(int id)
        {
            throw new NotImplementedException();
        }
        
    }
}
