﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository;

namespace TurksatSurveyAPI2.Services
{
    public class FlatService : IFlatService
    {
        private IUnitOfWork unitOfWork;

        public FlatService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public IQueryable<int> GetFlatsByID(int id)
        {
            return unitOfWork.FlatRepository.getAllwithBuildingID(id);
        }
    }
}
