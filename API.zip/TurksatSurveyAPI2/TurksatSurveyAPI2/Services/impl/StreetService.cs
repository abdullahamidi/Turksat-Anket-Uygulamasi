﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository;

namespace TurksatSurveyAPI2.Services
{
    public class StreetService : IStreetService
    {
        private IUnitOfWork unitOfWork;

        public StreetService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public IQueryable<Streets> GetStreetsByID(int id)
        {
            return unitOfWork.StreetRepository.getAllwithNeighborhoodID(id);
        }
    }
}
