﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository;

namespace TurksatSurveyAPI2.Services
{
    public class NeighborhoodService : INeighborhoodService
    {
        IUnitOfWork unitOfWork;

        public NeighborhoodService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public IQueryable<Neighborhoods> GetNeighborhoodsByID(int id)
        {
            return unitOfWork.NeighborhoodRepository.getAllwithDistrictID(id);
        }
    }
}
