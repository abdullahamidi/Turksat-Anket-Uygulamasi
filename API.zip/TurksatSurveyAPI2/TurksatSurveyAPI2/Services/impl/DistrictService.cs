﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository;

namespace TurksatSurveyAPI2.Services
{
    public class DistrictService : IDistrictService
    {
        private IUnitOfWork unitOfWork;
        public DistrictService(IUnitOfWork unitOfWork) { this.unitOfWork = unitOfWork; }
        public IQueryable<Districts> getByCityID(int id)
        {
            return unitOfWork.DistrictRepository.getAllwithCityID(id);
        }
    }
}
