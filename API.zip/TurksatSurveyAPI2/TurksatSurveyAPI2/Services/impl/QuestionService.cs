﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository;

namespace TurksatSurveyAPI2.Services.impl
{
    public class QuestionService : IQuestionService
    {
        IUnitOfWork unitOfWork;

        public QuestionService(IUnitOfWork unitOfWork) {
            this.unitOfWork = unitOfWork;
        }
        

        public IQueryable<Questions> getQuestionsBySurveyID(int survey_id)
        {
            return unitOfWork.QuestionRepository.getQuestionsBySurveyID(survey_id);
        }
    }
}
