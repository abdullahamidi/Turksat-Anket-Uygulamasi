﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Repository;

namespace TurksatSurveyAPI2.Services.impl
{
    public class AccountService : IAccountService
    {
        IUnitOfWork unitOfWork;

        public AccountService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public bool verifyAcc(string accName,string pwd)
        {
            return unitOfWork.AccountRepository.verifyAcc(accName,pwd);
        }
        public IQueryable<int> getuserID(string username, string pwd)
        {
            return unitOfWork.AccountRepository.getID(username, pwd);
        }
    }
}
