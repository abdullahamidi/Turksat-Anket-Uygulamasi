﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository;

namespace TurksatSurveyAPI2.Services.impl
{
    public class SurveyService : ISurveyService
    {
        IUnitOfWork unitOfWork;

        public SurveyService(IUnitOfWork unitOfWork) { this.unitOfWork = unitOfWork; }
        public IQueryable<Surveys> GetSurveys()
        {
            return unitOfWork.SurveyRepository.GetSurveys();
        }
    }
}
