﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Services
{
    public interface IAddressService
    {
        
        IQueryable<Districts> getDistrictswithTownID(int id);
        IQueryable<Neighborhoods> getNeighborhoodwithDistrictID(int id);
        IQueryable<Streets> getStreetswithNeighborhoodID(int id);
        IQueryable<Buildings> getBuildingswithStreetID(int id);
        IQueryable<Flats> getFlatswithBuildingID(int id);
    }
}
