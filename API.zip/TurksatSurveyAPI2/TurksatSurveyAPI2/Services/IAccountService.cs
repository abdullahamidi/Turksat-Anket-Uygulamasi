﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TurksatSurveyAPI2.Services
{
    public interface IAccountService
    {
        bool verifyAcc(string accName,string pwd);
        IQueryable<int> getuserID(string username, string pwd);
    }
}
