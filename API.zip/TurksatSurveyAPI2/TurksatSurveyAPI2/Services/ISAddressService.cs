﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Services
{
    public interface ISAddressService
    {
        void insertAddress(SurveyAddresses surveyAddresses);
        int getID();
    }
}
