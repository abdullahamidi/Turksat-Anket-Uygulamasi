﻿using System;
using System.Collections.Generic;

namespace TurksatSurveyAPI2.Models
{
    public partial class Flats : Entity
    {
        public int Id { get; set; }
        public int BuildingId { get; set; }
        public int FlatNumber { get; set; }

        public Buildings Building { get; set; }
    }
}
