﻿using System;
using System.Collections.Generic;

namespace TurksatSurveyAPI2.Models
{
    public partial class Streets : Entity
    {
        public Streets()
        {
            Buildings = new HashSet<Buildings>();
        }

        public int Id { get; set; }
        public int NeighborhoodId { get; set; }
        public string StreetName { get; set; }

        public Neighborhoods Neighborhood { get; set; }
        public ICollection<Buildings> Buildings { get; set; }
    }
}
