﻿using System;
using System.Collections.Generic;

namespace TurksatSurveyAPI2.Models
{
    public partial class Cities : Entity
    {
        public Cities()
        {
            Districts = new HashSet<Districts>();
        }

        public int Id { get; set; }
        public string CityName { get; set; }
        public string PlateNo { get; set; }
        public string PhoneCode { get; set; }

        public ICollection<Districts> Districts { get; set; }
    }
}
