﻿using System;
using System.Collections.Generic;

namespace TurksatSurveyAPI2.Models
{
    public partial class EmployeeAccounts : Entity
    {
        public EmployeeAccounts()
        {
            UserAnswers = new HashSet<UserAnswers>();
        }

        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeSurname { get; set; }
        public string EMail { get; set; }
        public string PhoneNumber { get; set; }

        public ICollection<UserAnswers> UserAnswers { get; set; }
    }
}
