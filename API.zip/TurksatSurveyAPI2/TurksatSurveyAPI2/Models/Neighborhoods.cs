﻿using System;
using System.Collections.Generic;

namespace TurksatSurveyAPI2.Models
{
    public partial class Neighborhoods : Entity
    {
        public Neighborhoods()
        {
            Streets = new HashSet<Streets>();
        }

        public int Id { get; set; }
        public int DistrictId { get; set; }
        public string NeighborhoodName { get; set; }
        public string ZipCode { get; set; }

        public Districts District { get; set; }
        public ICollection<Streets> Streets { get; set; }
    }
}
