﻿using System;
using System.Collections.Generic;

namespace TurksatSurveyAPI2.Models
{
    public partial class Buildings : Entity
    {
        public Buildings()
        {
            Flats = new HashSet<Flats>();
        }

        public int Id { get; set; }
        public int StreetId { get; set; }
        public string BuildingName { get; set; }

        public Streets Street { get; set; }
        public ICollection<Flats> Flats { get; set; }
    }
}
