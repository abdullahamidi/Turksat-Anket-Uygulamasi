﻿using System;
using System.Collections.Generic;

namespace TurksatSurveyAPI2.Models
{
    public partial class QuestionAnswers : Entity
    {
        public int Id { get; set; }
        public int QuestionId { get; set; }
        public string AnswerText { get; set; }

        public Questions Question { get; set; }
    }
}
