﻿using System;
using System.Collections.Generic;

namespace TurksatSurveyAPI2.Models
{
    public partial class Questions : Entity
    {
        public Questions()
        {
            QuestionAnswers = new HashSet<QuestionAnswers>();
            UserAnswers = new HashSet<UserAnswers>();
        }

        public int Id { get; set; }
        public string QuestionText { get; set; }
        public string SelectionType { get; set; }
        public int SurveyId { get; set; }

        public Surveys Survey { get; set; }
        public ICollection<QuestionAnswers> QuestionAnswers { get; set; }
        public ICollection<UserAnswers> UserAnswers { get; set; }
    }
}
