﻿using System;
using System.Collections.Generic;

namespace TurksatSurveyAPI2.Models
{
    public partial class UserAnswers : Entity
    {
        public int Id { get; set; }
        public int AddressId { get; set; }
        public int QuestionId { get; set; }
        public string AnswerText { get; set; }
        public int EmployeeId { get; set; }

        public SurveyAddresses Address { get; set; }
        public EmployeeAccounts Employee { get; set; }
        public Questions Question { get; set; }
    }
}
