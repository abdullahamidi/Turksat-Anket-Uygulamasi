﻿using System;
using System.Collections.Generic;

namespace TurksatSurveyAPI2.Models
{
    public partial class Surveys : Entity
    {
        public Surveys()
        {
            Questions = new HashSet<Questions>();
        }

        public int Id { get; set; }
        public string SurveyName { get; set; }
        public string Description { get; set; }

        public ICollection<Questions> Questions { get; set; }
    }
}
