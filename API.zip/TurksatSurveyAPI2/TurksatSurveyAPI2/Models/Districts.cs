﻿using System;
using System.Collections.Generic;

namespace TurksatSurveyAPI2.Models
{
    public partial class Districts : Entity
    {
        public Districts()
        {
            Neighborhoods = new HashSet<Neighborhoods>();
        }

        public int Id { get; set; }
        public int CityId { get; set; }
        public string DistrictName { get; set; }

        public Cities City { get; set; }
        public ICollection<Neighborhoods> Neighborhoods { get; set; }
    }
}
