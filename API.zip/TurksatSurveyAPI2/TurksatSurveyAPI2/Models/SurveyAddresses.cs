﻿using System;
using System.Collections.Generic;

namespace TurksatSurveyAPI2.Models
{
    public partial class SurveyAddresses : Entity
    {
        public SurveyAddresses()
        {
            UserAnswers = new HashSet<UserAnswers>();
        }

        public int Id { get; set; }
        public string CityName { get; set; }
        public string DistrictName { get; set; }
        public string NeighborhoodName { get; set; }
        public string StreetName { get; set; }
        public string BuildingName { get; set; }
        public int FlatNumber { get; set; }

        public ICollection<UserAnswers> UserAnswers { get; set; }
    }
}
