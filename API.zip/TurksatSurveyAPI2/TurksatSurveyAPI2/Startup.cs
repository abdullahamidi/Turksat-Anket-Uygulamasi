﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using TurksatSurveyAPI2;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository;
using TurksatSurveyAPI2.Services;
using TurksatSurveyAPI2.Services.impl;

namespace TurksatSurveyAPI2
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddScoped<AnketSistemiContext>();
            services.AddScoped<ICityService,CityService>();
            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
            services.AddScoped<IBuildingRepository, BuildingRepository>();
            services.AddScoped<IBuildingsService, BuildingsService>();
            services.AddScoped<IDistrictService, DistrictService>();
            services.AddScoped<IStreetService, StreetService>();
            services.AddScoped<IFlatService, FlatService>();
            services.AddScoped<INeighborhoodService, NeighborhoodService>();
            services.AddScoped<IAccountService,AccountService>();
            services.AddScoped<IUnitOfWork,UnitOfWork>();
            services.AddScoped<IQuestionService, QuestionService>();
            services.AddScoped<ISAddressService, SAddressService>();
            services.AddScoped<ISurveyService, SurveyService>();
            services.AddScoped<IAnswerService, AnswerService>();
            services.AddScoped<IUserAnswerService, UserAnswerService>();
            services.AddDbContext<AnketSistemiContext>(s => s.UseSqlServer("Server=tcp:turksatsurveydb.database.windows.net,1433;Initial Catalog=turksatsurveyDB;Persist Security Info=False;User ID=abdullahamidi;Password=123bnm123.A;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"));
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            app.UseHttpsRedirection();
            }
            app.UseMvc();
        }
    }
}
