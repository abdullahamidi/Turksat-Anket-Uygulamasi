﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TurksatSurveyAPI2
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
