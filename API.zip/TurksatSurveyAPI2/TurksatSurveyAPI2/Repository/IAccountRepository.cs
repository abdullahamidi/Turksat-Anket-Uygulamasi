﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository
{
    public interface IAccountRepository
    {
        bool verifyAcc(string accName,string pwd);
        IQueryable<int> getID(string username, string pwd);

    }
}
