﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository
{
    public interface ISurveyRepository
    {
        IQueryable<Surveys> GetSurveys(); 
    }
}
