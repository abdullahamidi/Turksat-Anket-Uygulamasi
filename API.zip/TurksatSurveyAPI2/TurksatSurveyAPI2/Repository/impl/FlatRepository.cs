﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository
{
    public class FlatRepository : Repository<Flats>, IFlatRepository
    {
        public FlatRepository(AnketSistemiContext context) : base(context)
        {
        }

        public IQueryable<int> getAllwithBuildingID(int id)
        {
            return context.Flats.Where(a => a.BuildingId == id).Select(a=> a.FlatNumber);
        }
    }
}
