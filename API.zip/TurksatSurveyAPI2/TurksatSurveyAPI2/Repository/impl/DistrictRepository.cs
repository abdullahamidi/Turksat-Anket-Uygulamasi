﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository
{
    public class DistrictRepository : Repository<Districts> ,IDistrictRepository
    {
        public DistrictRepository(AnketSistemiContext context) : base(context)
        {
        }

        public IQueryable<Districts> getAllwithCityID(int id)
        {
            return context.Districts.Where(a => a.CityId== id);
        }
    }
}
