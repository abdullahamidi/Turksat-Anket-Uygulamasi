﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository.impl
{
    public class AccountRepository : Repository<EmployeeAccounts>, IAccountRepository
    {
        public AccountRepository(AnketSistemiContext context) : base(context)
        {
        }

        

        public bool verifyAcc(string accName, string pwd)
        {
            bool result = false;
            foreach (var item in context.EmployeeAccounts.Select(a => a.Username))
            {
                if (accName == item)
                {
                    foreach (var password in context.EmployeeAccounts.Where(a => a.Username == accName).Select(a => a.Password))
                    {
                        if (pwd == password)
                        {
                            result = true;
                        }
                    }
                }
            }
            return result;
        }

        public IQueryable<int> getID(string username, string pwd)
        {
            return context.EmployeeAccounts.Where(a => a.Username == username&& a.Password == pwd).Select(a => a.Id);
        }
    }
}
