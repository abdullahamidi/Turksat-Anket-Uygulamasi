﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository.impl;

namespace TurksatSurveyAPI2.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private IBuildingRepository buildingRepository;
        private IDistrictRepository districtRepository;
        private INeighborhoodRepository neighborhoodRepository;
        private IAccountRepository accountRepository;
        private IStreetRepository streetRepository;
        private IFlatRepository flatRepository;
        private ICityRepository citiesRepository;
        private IQuestionRepository questionRepository;
        private ISurveyRepository surveyRepository;
        private IAnswerRepository answerRepository;
        private ISurveyAddressRepository sAddressRepository;
        private IUserAnswersRepository userAnswersRepository;
        private readonly AnketSistemiContext _databaseContext;
        public UnitOfWork(AnketSistemiContext databaseContext)
        { _databaseContext = databaseContext; }



        public IAccountRepository AccountRepository
        {
            get
            {
                return accountRepository = accountRepository ?? new AccountRepository(_databaseContext);
            }
        }
        

        public IBuildingRepository BuildingRepository {
            get
            {
                return buildingRepository = buildingRepository ?? new BuildingRepository(_databaseContext);
            }
        }

       

        public ICityRepository CitiesRepository{
            get { return citiesRepository = citiesRepository ?? new CityRepository(_databaseContext); }
        }

       

        public INeighborhoodRepository NeighborhoodRepository
        {
            get
            {
                return neighborhoodRepository= neighborhoodRepository ?? new NeighborhoodRepository(_databaseContext);
            }
        }

        public IStreetRepository StreetRepository
        {
            get
            {
                return streetRepository = streetRepository ?? new StreetRepository(_databaseContext);
            }
        }

        public IFlatRepository FlatRepository
        {
            get
            {
                return flatRepository = flatRepository?? new FlatRepository(_databaseContext);
            }
        }

        public IDistrictRepository DistrictRepository
        {
            get
            {
                return districtRepository = districtRepository ?? new DistrictRepository(_databaseContext);
            }
        }

        

        public IQuestionRepository QuestionRepository
        {
            get
            {
                return questionRepository = questionRepository ?? new QuestionRepository(_databaseContext);
            }
        }

        public ISurveyAddressRepository SAddressRepository
        {
            get
            {
                return sAddressRepository = sAddressRepository?? new SurveyAddressRepository(_databaseContext);
            }
        }

        public ISurveyRepository SurveyRepository
        {
            get
            {
                return surveyRepository = surveyRepository?? new SurveyRepository(_databaseContext);
            }
        }

        public IAnswerRepository AnswerRepository
        {
            get
            {
                return answerRepository = answerRepository?? new AnswerRepository(_databaseContext);
            }
        }

        public IUserAnswersRepository UserAnswersRepository {
            get
            {
                return userAnswersRepository = userAnswersRepository?? new UserAnswersRepository(_databaseContext);
            }
        }

        public void Save()
        { _databaseContext.SaveChanges(); }

    }
}
