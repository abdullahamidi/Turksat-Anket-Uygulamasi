﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository.impl
{
    public class SurveyRepository : Repository<Surveys>, ISurveyRepository
    {
        public SurveyRepository(AnketSistemiContext context) : base(context)
        {
        }

        public IQueryable<Surveys> GetSurveys()
        {
            return context.Surveys;
        }
    }
}
