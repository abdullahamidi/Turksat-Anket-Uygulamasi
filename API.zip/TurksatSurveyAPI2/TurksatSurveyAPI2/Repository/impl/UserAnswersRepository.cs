﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository.impl
{
    public class UserAnswersRepository : Repository<UserAnswers> ,IUserAnswersRepository
    {
        public UserAnswersRepository(AnketSistemiContext context) : base(context)
        {
        }

        public void insertUserAnswers(UserAnswers userAnswers)
        {
            context.Set<UserAnswers>().Add(userAnswers);
            context.SaveChanges();
        }
    }
}
