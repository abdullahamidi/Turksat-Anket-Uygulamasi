﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository
{
    public class CityRepository : Repository<Cities>,ICityRepository
    {
        public CityRepository(AnketSistemiContext context) : base(context)
        {
        }

        public IQueryable<Cities> getAllCities()
        {
            return context.Cities.Select(a => new Cities{CityName=  a.CityName,Id =  a.Id});
        }

       
    }
}


