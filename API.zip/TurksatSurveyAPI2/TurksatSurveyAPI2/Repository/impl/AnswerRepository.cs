﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2;
using TurksatSurveyAPI2.Models;
using Microsoft.EntityFrameworkCore;

namespace TurksatSurveyAPI2
{
    public class AnswerRepository : Repository<QuestionAnswers>, IAnswerRepository
    {
        public AnswerRepository(AnketSistemiContext context) : base(context)
        {
        }

        public IQueryable<QuestionAnswers> getAnswersByQuestionID(int id)
        {
            return context.QuestionAnswers.Where(a=>a.QuestionId== id);
        }
    }
}
