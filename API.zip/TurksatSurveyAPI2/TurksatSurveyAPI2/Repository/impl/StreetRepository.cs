﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository
{
    public class StreetRepository : Repository<Streets>, IStreetRepository
    {
        public StreetRepository(AnketSistemiContext context) : base(context)
        {
        }

        public IQueryable<Streets> getAllwithNeighborhoodID(int id)
        {
            return context.Streets.Where(a => a.NeighborhoodId == id);
        }
    }
}
