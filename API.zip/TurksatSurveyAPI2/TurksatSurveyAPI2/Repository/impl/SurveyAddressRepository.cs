﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository.impl
{
    public class SurveyAddressRepository : Repository<SurveyAddresses>, ISurveyAddressRepository
    {
        static int saID;
        public SurveyAddressRepository(AnketSistemiContext context) : base(context)
        {
        }

        public int getID()
        {
            return saID;
        }

        public void addSAddress(SurveyAddresses sAddress)
        {
            if (sAddress == null) throw new ArgumentNullException("entity");

            if(context.SurveyAddresses.Any(a=> 
            a.CityName == sAddress.CityName && 
            a.DistrictName == sAddress.DistrictName && 
            a.BuildingName == sAddress.BuildingName && 
            a.NeighborhoodName == sAddress.NeighborhoodName && 
            a.StreetName ==sAddress.StreetName && 
            a.FlatNumber == sAddress.FlatNumber))
            {
                saID = context.SurveyAddresses.Where(a =>
            a.CityName == sAddress.CityName &&
            a.DistrictName == sAddress.DistrictName &&
            a.BuildingName == sAddress.BuildingName &&
            a.NeighborhoodName == sAddress.NeighborhoodName &&
            a.StreetName == sAddress.StreetName &&
            a.FlatNumber == sAddress.FlatNumber).Select(a => a.Id).First();
            }
            else
            {
            context.Set<SurveyAddresses>().Add(sAddress);
            context.SaveChanges();
            saID = sAddress.Id;
            }
        }
    }
}
