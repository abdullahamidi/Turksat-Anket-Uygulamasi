﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2
{
    public class Repository<T> : IRepository<T> where T : Entity
    {
        public readonly AnketSistemiContext context;

        private DbSet<T> entities;

        public Repository(AnketSistemiContext context)
        {
            this.context = context;
            entities = context.Set<T>();
        }

        public void delete(int id)
        {
            T entity = entities.SingleOrDefault(a=> a.Id == id);
            entities.Remove(entity);
        }
        
        public T getById(int id)
        {
             return entities.SingleOrDefault(a => a.Id == id);
            
        }
        
        public void insert(T entity)
        {
            if (entity == null) throw new ArgumentNullException("entity");
            entities.Add(entity);
            context.SaveChanges();
        }

        public void update(T entity)
        {
            
        }
    }
}
