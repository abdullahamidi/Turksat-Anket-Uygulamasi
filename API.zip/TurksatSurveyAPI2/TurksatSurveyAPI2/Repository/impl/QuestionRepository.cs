﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository.impl
{
    public class QuestionRepository : Repository<Questions>, IQuestionRepository
    {
        public QuestionRepository(AnketSistemiContext context) : base(context)
        {
        }

        public IQueryable<Questions> getQuestionsBySurveyID(int id)
        {
            return context.Questions.Where(a=> a.SurveyId == id);
        }
    }
        
}
