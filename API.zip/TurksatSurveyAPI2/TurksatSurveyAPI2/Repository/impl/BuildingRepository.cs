﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository
{
    public class BuildingRepository : Repository<Buildings>, IBuildingRepository
    {
        public BuildingRepository(AnketSistemiContext context) : base(context)
        {
        }
        public IQueryable<Buildings> getAllwithStreetID(int id)
        {
            return context.Buildings.Where(a => a.StreetId == id);
        }
    }
}
