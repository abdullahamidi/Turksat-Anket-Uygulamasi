﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository
{
    public class NeighborhoodRepository : Repository<Neighborhoods>, INeighborhoodRepository
    {
        public NeighborhoodRepository(AnketSistemiContext context) : base(context)
        {
        }

        public IQueryable<Neighborhoods> getAllwithDistrictID(int id)
        {
            return context.Neighborhoods.Where(a => a.DistrictId == id);
        }
    }
}
