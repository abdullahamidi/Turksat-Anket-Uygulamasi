﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2
{
    public interface IRepository<T> where T : Entity
    {
        T getById(int id);
        void insert(T entity);
        void update(T entity);
        void delete(int id);
    }
}
