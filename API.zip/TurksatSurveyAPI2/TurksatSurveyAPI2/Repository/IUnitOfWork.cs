﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TurksatSurveyAPI2;
using TurksatSurveyAPI2.Models;

namespace TurksatSurveyAPI2.Repository
{
    public interface IUnitOfWork
    {
        IBuildingRepository BuildingRepository { get; }
        IAccountRepository AccountRepository { get; }
        INeighborhoodRepository NeighborhoodRepository { get; }
        IStreetRepository StreetRepository { get; }
        IFlatRepository FlatRepository { get; }
        IDistrictRepository DistrictRepository { get; }
        ICityRepository CitiesRepository { get; }
        IQuestionRepository QuestionRepository { get; }
        ISurveyRepository SurveyRepository { get; }
        IAnswerRepository AnswerRepository { get; }
        ISurveyAddressRepository SAddressRepository { get; }
        IUserAnswersRepository UserAnswersRepository { get; }

        void Save();

    }
}
