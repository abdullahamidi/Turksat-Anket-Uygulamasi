﻿namespace TurksatSurveyAPI2.Controllers
{
    public class BuildingModel
    {
        public int Id { get; set; }
        public string BuildingName { get; set; }
    }
}