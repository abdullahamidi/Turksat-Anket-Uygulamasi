﻿
    public class QuestionModel
    {
    public int ID { get; set; }
    public string questionText { get; set; }
    public string selectionType { get; set; }
}

