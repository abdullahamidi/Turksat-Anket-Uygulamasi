﻿public class CityModel
{
    public int Id { get; set; }
    public string CityName { get; set; }
}