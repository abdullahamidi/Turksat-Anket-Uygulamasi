﻿
    public class DistrictModel
    {
        public int Id { get; set; }
        public string DistrictName { get; set; }
    }

