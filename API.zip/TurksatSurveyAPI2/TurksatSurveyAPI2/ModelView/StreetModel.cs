﻿public class StreetModel
{
    public int Id { get; set; }
    public string StreetName { get; set; }
}