﻿using System;

public class NeighborhoodModel
{
    public int Id { get; set; }
    public string NeighborhoodName { get; set; }
}