﻿
public class SurveyModel
{
    public int Id { get; set; }
    public string surveyName { get; set; }
    public string description { get; set; }
}