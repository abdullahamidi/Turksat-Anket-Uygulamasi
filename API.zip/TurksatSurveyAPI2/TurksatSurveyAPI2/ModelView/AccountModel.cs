﻿
public class AccountModel
{
    public int ID { get; set; }
    public bool isVerified { get; set; }
}
