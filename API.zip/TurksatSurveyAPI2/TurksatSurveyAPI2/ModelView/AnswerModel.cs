﻿public class AnswerModel
{
    public int id { get; set; }
    public string answerText { get; set; }
}