﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Services;

namespace TurksatSurveyAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NeighborhoodsController : ControllerBase
    {
        private readonly INeighborhoodService neighborhoodService;

        public NeighborhoodsController(INeighborhoodService neighborhoodService)
        {
            this.neighborhoodService = neighborhoodService;
        }

        [HttpGet("{id}")]
        public IQueryable<NeighborhoodModel> getByID(int id)
        {
            return neighborhoodService.GetNeighborhoodsByID(id).Select(a=> new NeighborhoodModel {Id = a.Id, NeighborhoodName = a.NeighborhoodName});
        }
    }
    
}
