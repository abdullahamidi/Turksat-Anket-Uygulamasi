﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TurksatSurveyAPI2.Services;

namespace TurksatSurveyAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnswersController : ControllerBase
    {
        IAnswerService answerService;

        public AnswersController(IAnswerService answerService)
        {
            this.answerService = answerService;
        }


        [HttpGet("{id}")]
        public IQueryable<AnswerModel> getAnswers(int id)
        {
            return answerService.getAnswerByQuestionID(id).Select(a => new AnswerModel {id = a.Id, answerText = a.AnswerText });
        }
    }
}
