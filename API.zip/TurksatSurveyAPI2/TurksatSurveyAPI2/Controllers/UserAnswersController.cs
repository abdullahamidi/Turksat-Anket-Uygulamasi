﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Services;

namespace TurksatSurveyAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserAnswersController : ControllerBase
    {
        IUserAnswerService userAnswerService;

        public UserAnswersController(IUserAnswerService userAnswerService)
        {
            this.userAnswerService = userAnswerService;
        }

        [HttpPost("")]
        public void insertAnswers([FromBody]UserAnswers userAnswers)
        {
            userAnswerService.insertUserAnswers(userAnswers);
        }
    }
}