﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TurksatSurveyAPI2.Services;

namespace TurksatSurveyAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SurveysController : ControllerBase
    {
        ISurveyService surveyService;

        public SurveysController(ISurveyService surveyService) {
            this.surveyService = surveyService;
        }

        [HttpGet]
        public IQueryable<SurveyModel> getSurveys()
        {
            return surveyService.GetSurveys().Select(a => new SurveyModel {Id = a.Id,surveyName = a.SurveyName, description = a.Description });
        }
    }
}