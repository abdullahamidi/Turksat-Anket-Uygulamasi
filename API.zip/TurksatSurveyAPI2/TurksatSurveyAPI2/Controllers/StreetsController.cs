﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Services;

namespace TurksatSurveyAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StreetsController : ControllerBase
    {
        private IStreetService streetService;

        public StreetsController(IStreetService streetService)
        {
            this.streetService = streetService;
        }
        [HttpGet("{id}")]
        public IQueryable<StreetModel> getByID(int id)
        {
            return streetService.GetStreetsByID(id).Select(a=> new StreetModel {Id = a.Id, StreetName = a.StreetName});
        }
    }
}
