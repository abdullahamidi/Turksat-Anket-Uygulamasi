﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TurksatSurveyAPI2.Services;

namespace TurksatSurveyAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        IAccountService accountService;

        public AccountsController(IAccountService accountService)
        {
            this.accountService = accountService;
        }
        
        [HttpGet("{str}/{pwd}")]
        public IQueryable<int> getID(string str, string pwd)
        {
                return accountService.getuserID(str, pwd);
        }

        [HttpGet("verify/{str}/{pwd}")]
        public bool verify(string str, string pwd)
        {
            if (accountService.verifyAcc(str, pwd))
            {
                return true;
            }
            else return false;
        }

    }
}