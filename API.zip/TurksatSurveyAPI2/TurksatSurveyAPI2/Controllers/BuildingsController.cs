﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Repository;
using TurksatSurveyAPI2.Services;

namespace TurksatSurveyAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BuildingsController : ControllerBase
    {
        private readonly IBuildingsService buildingService;

        public BuildingsController(IBuildingsService buildingService)
        {
            this.buildingService = buildingService;
        }
        // GET: api/Buildings
        [HttpGet("{id}")]
        public IQueryable<BuildingModel> GetAllBuildingsByStreetID(int id) =>
            buildingService.getBuildingByID(id).Select(a=> new BuildingModel{Id = a.Id, BuildingName = a.BuildingName });
    }
}