﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Services;

namespace TurksatSurveyAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SurveyAddressesController : ControllerBase
    {
       
        ISAddressService sAddressesService;

        public SurveyAddressesController(ISAddressService sAddressesService)
        {
            this.sAddressesService = sAddressesService;
        }

        [HttpPost("")]
        public void insertAddress([FromBody] SurveyAddresses address)
        {
            sAddressesService.insertAddress(address);
            
        }

        [HttpGet]
        public int getID()
        {
            return sAddressesService.getID();
        }
    }
}