﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TurksatSurveyAPI2.Models;
using TurksatSurveyAPI2.Services;

namespace TurksatSurveyAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CitiesController : ControllerBase
    {
        private ICityService _cityService;

        public CitiesController(ICityService cityService)
        {
           _cityService= cityService;
        }
        
        
        [HttpGet]
        public IQueryable<CityModel> getAllCities() { 
            return _cityService.getAllCities().Select(a=> new CityModel {CityName =a.CityName,Id=a.Id });
        }

        
    }
}
