﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TurksatSurveyAPI2
{
    public class Entity : IEntity
    {
        public int Id { get; set; }
    }
}
